-- cPanel mysql backup
GRANT USAGE ON *.* TO 'keithlab'@'localhost' IDENTIFIED BY PASSWORD '*2D7C5A8784FC82B46A51078112878B2C0D03F37C';
GRANT ALL PRIVILEGES ON `keithlab\_%`.* TO 'keithlab'@'localhost';
